# Blackcamp Theme for Clover

Blackcamp is a theme for clover inspired by original boot from Apple

![alt tag](https://raw.githubusercontent.com/solidusnake/blackcamp-theme/master/screenshot.png)
